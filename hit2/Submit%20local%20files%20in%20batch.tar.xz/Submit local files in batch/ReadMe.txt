This script is used to batch submit pdb data to http://seppa3.badd-cao.net/submission.html

Please note that:
1.There are four files in this compressed file, including websubmit.py, Example_pdb, example.txt, ReadMe.txt and geckodriver.exe(webdriver for Firefox).
	1.1 websubmit.py----the submition script to http://seppa3.badd-cao.net/submission.html.
	1.2 Example_pdb----Put the pdb file in this folder.
	1.3 example.txt----Includes pdb file path, email, pdb file name, chain id, subcellular localization of antigen, species of the immune host and threshold.
	1.4 ReadMe.txt----Introduce the process of submitting files in batches.
	1.5 geckodriver.exe----webdriver for Firefox.

2.Users need to install python package selenium before running the script.

	##pip install selenium

3.You need to change the following files.

	3.1 example.txt----Fill in your email and fill in the information you want to submit in the format.
	3.2 Example_pdb----Put the pdb file in the folder (Example_pdb).
	
4.Download the driver for the corresponding browser. For example, Your browser is Firefox, you need to download the corresponding driver for Firefox(geckodriver.exe).When you download the driver, put the driver in the same path of the websubmit.py.

	4.1 IEdriver----http://selenium-release.storage.googleapis.com/index.html
	4.2 Chromedriver----http://chromedriver.storage.googleapis.com/index.html
	4.3 Firefoxdriver----https://github.com/mozilla/geckodriver/releases

5.If your browser is Firefox, you can open the terminal and run program. You need to enter the path to websubmit.py. Run the following code to complete the submission.
	
	##cd ~PATH
	##python websubmit.py
	
6.If your browser is not Firefox, you should modify the corresponding code in the websubmit.py. In line 38 of the script is 

	##browser = webdriver.Firefox()
  
  You need to change to your own browser, such as :

	##browser = webdriver.Chrome()

	##browser = webdriver.Ie()
	
	##browser = webdriver.Edge()
	
	##browser = webdriver.Opera()
	
  Then you can run the program
	
	##cd ~PATH
	##python websubmit.py
