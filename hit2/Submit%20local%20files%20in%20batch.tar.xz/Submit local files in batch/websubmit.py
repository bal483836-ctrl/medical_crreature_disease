# -*- coding: utf-8 -*-
"""
Created on Tue Dec 25 13:29:41 2018

@author: 29484
"""

#batch submit to 'http://seppa3.badd-cao.net/submission.html'
from selenium import webdriver
import time
import os
#read example.txt
getcwd=os.getcwd()
sample_path=os.path.join(getcwd,'example.txt')
with open(sample_path,'r') as openfile:
    lines=openfile.readlines()
pdb_path=os.path.join(getcwd,'Example_pdb')  #first line: pdb file path
email=lines[2].strip()     #third line: user email
pdb_list=[]                    #from fourth line, the first column is pdb file name
chain_list=[]                  #from fourth line, the second column is chain id
locat_list=[]                  #from fourth line, the third column is Subcellular Localization of Antigen
species_list=[]                #from fourth line, the third column is Species of the Immune Host
thresh_list=[]                 #from fourth line, the third column is threshold
for line in lines[3:]:
    pdb,chain,thresh,locat,spec=line.split()
    pdb_list.append(pdb.strip())
    chain_list.append(chain.strip())
    locat_list.append(locat.strip())
    species_list.append(spec.strip())
    thresh_list.append(thresh.strip())
                           
#submit
def submit(excu):
    web_addr='http://seppa3.badd-cao.net/submission.html'      #Internet site
    if excu:
        for i in range(len(pdb_list)):
            ##### You need to change it here #########          
            browser = webdriver.Firefox()
            ##########################################
            browser.get(web_addr)
            browser.implicitly_wait(10)
            pdbname =pdb_list[i]
            chainid=chain_list[i]
            thresh=thresh_list[i]
            locat=locat_list[i]
            spec=species_list[i]
            #click submit type
            browser.find_element_by_xpath('//input[@value="12"]').click()
            #input pdb file
            browser.find_element_by_xpath('//input[@id="filename"]').send_keys(os.path.join(pdb_path,pdbname))
            #input chainid
            browser.find_element_by_id('5IF0_G_2').send_keys(chainid)
            #input location
            if locat.title()=='Membrane':
                browser.find_element_by_xpath('//input[@value="21"]').click()
            elif locat.title=='Secreted':
                browser.find_element_by_xpath('//input[@value="22"]').click()
            elif locat.title=='Unspecified':
                browser.find_element_by_xpath('//input[@value="23"]').click()
            #input species
            if spec.title()=='Homo':
                browser.find_element_by_xpath('//input[@value="31"]').click()
            elif spec.title=='Mus':
                browser.find_element_by_xpath('//input[@value="32"]').click()
            elif spec.title=='Unspecified':
                browser.find_element_by_xpath('//input[@value="33"]').click()
            #input email
            browser.find_element_by_name("email").send_keys(email)
            #input threshold
            thr=browser.find_element_by_id('default_threshold')           
            thr.clear()
            thr.send_keys(thresh)
            #submit
            browser.find_element_by_id("forbatch").click()
            time.sleep(30)

submit(True)            
                
            
            
            
            
           